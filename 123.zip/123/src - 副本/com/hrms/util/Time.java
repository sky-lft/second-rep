package com.hrms.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Time {
	
	public static int getCurrentAgeByBirthdate(String brithday)
			   throws ParseException, Exception {
			  try {
			   Calendar calendar = Calendar.getInstance();
			   SimpleDateFormat formatDate = new SimpleDateFormat("yyyy-MM-dd");
			   String currentTime = formatDate.format(calendar.getTime());
			   Date today = formatDate.parse(currentTime);
			   Date brithDay = formatDate.parse(brithday);
			 
			   return today.getYear() - brithDay.getYear();
			  } catch (Exception e) {
			   return 0;
			  }
			 }

}
