package com.hrms.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.hrms.model.Staff;


public class Dsql {

      	public static List<Staff> seleByStaff(Map<String, Object> maps,String orderBy){
      		
      		StringBuilder sb = new StringBuilder();
            sb.append("select * from staff ").append(" where 1=1 ");
            List<Object> values = new ArrayList<Object>();
            for(Entry<String,Object> entry:maps.entrySet()){
                if(entry.getValue() != null){
                    sb.append(" and ").append(entry.getKey()).append("=?");
                    values.add(entry.getValue());
                }
            }
            sb.append(" ").append(orderBy);
            return Staff.dao.find(sb.toString(), values.toArray());
      	}
	
}
