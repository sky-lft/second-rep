package com.hrms.util;

import com.jfinal.plugin.activerecord.Model;

public class StrongModel extends Model{

	

}
