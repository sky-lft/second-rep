package com.hrms.controller;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.hrms.model.Degree;
import com.hrms.model.Login;
import com.hrms.model.Staff;
import com.hrms.model.Title;
import com.jfinal.core.Controller;

public class StaffController extends Controller {
	public void index(){
			
		render("index.html");
	}
	
	
	public void list(){
		
		
		setAttr("page", Staff.dao.paginate(getParaToInt(0,1), getParaToInt(1,5)));
		render("/admin/staff_list.html");
	}
	 public void add(){
			
		    List<Degree> degrees = Degree.dao.getAll();
		    List<Title> titles =Title.dao.getAll();
		    setAttr("de", degrees);
		    setAttr("ti", titles);
			render("/admin/staff_add.html");
		}
	 public void doAdd(){
			  Staff st = getModel(Staff.class, "st");
			 
			  Calendar cal_birth=Calendar.getInstance();  
			  Calendar cal_start=Calendar.getInstance();  
			  Calendar cal_end=Calendar.getInstance();  
			  Calendar cal_now=Calendar.getInstance();  
			  cal_birth.setTime(st.getBirth()); 
			  cal_start.setTime(st.getStartTime());
			  cal_end.setTime(st.getEndTime());
			  cal_now.setTime(new Date());			
			  int age =  cal_now.get(Calendar.YEAR)-cal_birth.get(Calendar.YEAR);
			  st.setAge(age);
			  
			  st.getBirth().getTime();
			  
			  if(st.save()){
				  redirect("/staff/list");
				  //renderHtml("<script>parent.parent.location.href='/staff' </script");
			  }else{
				  renderHtml("<script>alert('添加失败');history.go(-1)</script>");
			  }
			  
			  
		     //renderJson(a);
			// render("/admin/staff_add.html");
		}
	

}
