package com.hrms.controller;

import java.awt.image.RenderedImage;

import com.hrms.model.Login;
import com.jfinal.core.Controller;


public class LoginController extends Controller {
	
	
	public void loginIn(){		
	String user = getPara("user");	
	String password =getPara("password");
		if(this.validateCaptcha("codeImg")){
			if(user!="" || user!=null){
				Login newLogin = Login.dao.findFirst("select * from login where user = ?",user);
                   if(newLogin!=null){
                	   if(password!="" || password !=null){
                		   if(password.equals(newLogin.getPassword())){
                			 System.out.println("================到这里了=======================");
                			   getSession().setAttribute("alogin", newLogin);
                			   getSession().setAttribute("sd", "注册");
                			   
                			   redirect("/staff");
                		   }else{
                			   renderHtml("<script>alert('密码错误')</script>"); 
                		   }
                		   
                	   }else{
                		   
                		   renderHtml("<script>alert('请输入密码')</script>"); 
                	   }
                	   
                   }else{
                	   renderHtml("<script>alert('该用户名不存在')</script>");
                	   
                   }  
				
				
			}else{renderHtml("<script>alert('请输入用户名')</script>");
			}
			
			
			
			
		}else{
			
			renderHtml("<script>alert('验证码不正确');window.location='/login'</script>");
		}
		

	}
	
	public void index(){
		
		render("login.html");
	}
	public void img(){
		
		renderCaptcha();
	}
	public void exit(){
		
		getSession().removeAttribute("login");
	}

}
